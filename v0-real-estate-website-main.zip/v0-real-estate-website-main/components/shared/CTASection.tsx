'use client';

import { useLocale, useTranslations } from 'next-intl';
import { Link } from '@/i18n/routing';
import { Button } from '@/components/ui/button';
import { AnimatedReveal } from './AnimatedReveal';
import { cn } from '@/lib/utils';

export function CTASection() {
  const t = useTranslations('sections');
  const tCta = useTranslations('cta');
  const locale = useLocale();
  const isRtl = locale === 'ar';

  return (
    <section className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-primary/10 to-transparent" />
      <div className="absolute inset-0 bg-card/50" />

      <div className="container mx-auto px-4 relative z-10">
        <AnimatedReveal>
          <div className={cn(
            'max-w-3xl mx-auto text-center',
            isRtl && 'text-center'
          )}>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 text-balance">
              {t('ctaTitle')}
            </h2>
            <p className="text-lg text-muted-foreground mb-8 text-pretty">
              {t('ctaDesc')}
            </p>
            <Link href="/contact">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-6 text-lg"
              >
                {tCta('contactNow')}
              </Button>
            </Link>
          </div>
        </AnimatedReveal>
      </div>
    </section>
  );
}
