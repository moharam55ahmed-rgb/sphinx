'use client';

import { useLocale, useTranslations } from 'next-intl';
import { Link } from '@/i18n/routing';
import { Facebook, Youtube, Instagram, Phone, Mail, MapPin } from 'lucide-react';
import { cn } from '@/lib/utils';
import { projects, contactInfo, socialLinks } from '@/data/site';

export function Footer() {
  const t = useTranslations('footer');
  const tNav = useTranslations('nav');
  const locale = useLocale();
  const isRtl = locale === 'ar';

  const quickLinks = [
    { href: '/', label: tNav('home') },
    { href: '/about', label: tNav('about') },
    { href: '/projects', label: tNav('projects') },
    { href: '/news', label: tNav('news') },
    { href: '/careers', label: tNav('careers') },
    { href: '/contact', label: tNav('contact') },
  ];

  return (
    <footer className="bg-secondary border-t border-white/10">
      <div className="container mx-auto px-4 py-16">
        <div className={cn(
          'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10',
          isRtl && 'text-right'
        )}>
          {/* About Column */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white">
              {isRtl ? 'سفنكس للتطوير العقاري' : 'SPHINX Real Estate'}
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              {t('about')}
            </p>
            <div className={cn('flex gap-3', isRtl && 'justify-end')}>
              <a
                href={socialLinks.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/60 hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href={socialLinks.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/60 hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <Youtube className="w-5 h-5" />
              </a>
              <a
                href={socialLinks.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/60 hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">{t('quickLinks')}</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-muted-foreground hover:text-primary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Projects */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">{t('ourProjects')}</h3>
            <ul className="space-y-2">
              {projects.map((project) => (
                <li key={project.slug}>
                  <Link
                    href={`/projects/${project.slug}`}
                    className="text-muted-foreground hover:text-primary transition-colors text-sm"
                  >
                    {isRtl ? project.nameAr : project.nameEn}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">{t('contactInfo')}</h3>
            <ul className="space-y-3">
              <li className={cn('flex items-start gap-3', isRtl && 'flex-row-reverse')}>
                <Phone className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-muted-foreground text-sm">{contactInfo.phone}</span>
              </li>
              <li className={cn('flex items-start gap-3', isRtl && 'flex-row-reverse')}>
                <Mail className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-muted-foreground text-sm">{contactInfo.email}</span>
              </li>
              <li className={cn('flex items-start gap-3', isRtl && 'flex-row-reverse')}>
                <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-muted-foreground text-sm">
                  {isRtl ? contactInfo.addressAr : contactInfo.addressEn}
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 py-6">
          <p className={cn('text-center text-muted-foreground text-sm', isRtl && 'text-center')}>
            {t('copyright')}
          </p>
        </div>
      </div>
    </footer>
  );
}
