'use client';

import { useState, useEffect } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { Link, usePathname } from '@/i18n/routing';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetTrigger, SheetClose } from '@/components/ui/sheet';
import { cn } from '@/lib/utils';
import { LanguageSwitcher } from './LanguageSwitcher';
import { projects } from '@/data/site';

export function Header() {
  const t = useTranslations('nav');
  const tCta = useTranslations('cta');
  const locale = useLocale();
  const pathname = usePathname();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const isRtl = locale === 'ar';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { href: '/', label: t('home') },
    { href: '/about', label: t('about') },
    {
      href: '/projects',
      label: t('projects'),
      dropdown: projects.map((p) => ({
        href: `/projects/${p.slug}`,
        label: isRtl ? p.nameAr : p.nameEn,
      })),
    },
    {
      href: '/gallery/photos',
      label: t('gallery'),
      dropdown: [
        { href: '/gallery/photos', label: t('photos') },
        { href: '/gallery/videos', label: t('videos') },
      ],
    },
    { href: '/news', label: t('news') },
    { href: '/team', label: t('team') },
    { href: '/careers', label: t('careers') },
    { href: '/contact', label: t('contact') },
  ];

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        isScrolled
          ? 'bg-background/95 backdrop-blur-xl border-b border-white/10 py-3'
          : 'bg-transparent py-5'
      )}
    >
      <div className="container mx-auto px-4">
        <div className={cn('flex items-center justify-between', isRtl && 'flex-row-reverse')}>
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="relative h-10 w-auto">
              <span className="text-xl font-bold text-white tracking-wide">
                {isRtl ? 'سفنكس' : 'SPHINX'}
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav
            className={cn(
              'hidden lg:flex items-center gap-1',
              isRtl && 'flex-row-reverse'
            )}
          >
            {navItems.map((item) =>
              item.dropdown ? (
                <DropdownMenu key={item.href}>
                  <DropdownMenuTrigger asChild>
                    <button
                      className={cn(
                        'flex items-center gap-1 px-4 py-2 text-sm font-medium text-white/80 hover:text-white transition-colors',
                        pathname.startsWith(item.href) && 'text-primary'
                      )}
                    >
                      {item.label}
                      <ChevronDown className="w-4 h-4" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    align={isRtl ? 'end' : 'start'}
                    className="bg-card/95 backdrop-blur-xl border-white/10"
                  >
                    {item.dropdown.map((subItem) => (
                      <DropdownMenuItem key={subItem.href} asChild>
                        <Link
                          href={subItem.href}
                          className="cursor-pointer text-white/80 hover:text-white hover:bg-white/5"
                        >
                          {subItem.label}
                        </Link>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'px-4 py-2 text-sm font-medium text-white/80 hover:text-white transition-colors',
                    pathname === item.href && 'text-primary'
                  )}
                >
                  {item.label}
                </Link>
              )
            )}
          </nav>

          {/* Actions */}
          <div className={cn('flex items-center gap-3', isRtl && 'flex-row-reverse')}>
            <LanguageSwitcher />

            <Link href="/contact" className="hidden lg:block">
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                {tCta('contactUs')}
              </Button>
            </Link>

            {/* Mobile Menu */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon" className="text-white">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side={isRtl ? 'right' : 'left'}
                className="bg-background border-white/10 w-[300px]"
              >
                <div className="flex flex-col gap-6 mt-8">
                  <div className="flex items-center justify-between">
                    <span className="text-xl font-bold text-white">
                      {isRtl ? 'سفنكس' : 'SPHINX'}
                    </span>
                    <SheetClose asChild>
                      <Button variant="ghost" size="icon" className="text-white">
                        <X className="w-5 h-5" />
                      </Button>
                    </SheetClose>
                  </div>

                  <nav className="flex flex-col gap-2">
                    {navItems.map((item) => (
                      <div key={item.href}>
                        <SheetClose asChild>
                          <Link
                            href={item.href}
                            className={cn(
                              'block px-4 py-3 text-base font-medium text-white/80 hover:text-white hover:bg-white/5 rounded-lg transition-colors',
                              pathname === item.href && 'text-primary bg-white/5'
                            )}
                          >
                            {item.label}
                          </Link>
                        </SheetClose>
                        {item.dropdown && (
                          <div className={cn('mt-1', isRtl ? 'pr-4' : 'pl-4')}>
                            {item.dropdown.map((subItem) => (
                              <SheetClose asChild key={subItem.href}>
                                <Link
                                  href={subItem.href}
                                  className="block px-4 py-2 text-sm text-white/60 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                                >
                                  {subItem.label}
                                </Link>
                              </SheetClose>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </nav>

                  <div className="pt-4 border-t border-white/10">
                    <Link href="/contact" className="block">
                      <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                        {tCta('contactUs')}
                      </Button>
                    </Link>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </motion.header>
  );
}
